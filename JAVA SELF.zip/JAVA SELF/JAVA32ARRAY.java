public class JAVA32ARRAY {
    public static void main(String[] args) {
        int[] marks=new int[3];
        marks[0]=23;
        marks[1]=24;
        marks[2]=32;
        
        // System.out.println(marks[0]);
        // System.out.println(marks[1]);
        // System.out.println(marks[2]);


        //using for loop

        for(int i=0;i<3;i++)
        {
            System.out.println(marks[i]);
        }
    }
}
