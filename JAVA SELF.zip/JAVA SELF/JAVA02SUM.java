public class JAVA02SUM {
    public static void main(String[] args){
        int a=10;
        int b=20;
        int c=30;
        int d=a+b+c;
        System.out.println("Sum is "+ d);
    }
}
