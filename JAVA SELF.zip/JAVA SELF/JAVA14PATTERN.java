// solid rectangele 
/*
    
    *****
    *****
    *****
    *****

 */


public class JAVA14PATTERN {
    public static void main(String[] args) {
        for(int i=0;i<=3;i++) // for rows
        {
            for(int j=0;j<=4;j++) // for columns
            {
                System.out.print("* ");
            }
            System.out.print("\n");
        }
    }
}
